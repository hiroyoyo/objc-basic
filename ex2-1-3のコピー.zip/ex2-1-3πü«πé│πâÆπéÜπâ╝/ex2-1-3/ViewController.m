//
//  ViewController.m
//  ex2-1-3
//
//  Created by 佐野浩代 on 2017/01/03.
//  Copyright © 2017年 佐野浩代. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property NSArray *images;
@property (weak, nonatomic) IBOutlet UIImageView *background;
@property (weak, nonatomic) IBOutlet UIButton *change;


@end
@implementation ViewController

- (IBAction)change:(id)sender{
    for (int i = 0; i < 4; i++) {
        self.background.image = _images[i];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _images =@[@"cinamon",@"kikilala",@"kitty",@"mymelody",@"pompom,purin"];
    
    _background.image = [UIImage imageNamed:_images[0]];
    
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
