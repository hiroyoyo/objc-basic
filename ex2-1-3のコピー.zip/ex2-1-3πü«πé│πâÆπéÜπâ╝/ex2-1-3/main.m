//
//  main.m
//  ex2-1-3
//
//  Created by 佐野浩代 on 2017/01/03.
//  Copyright © 2017年 佐野浩代. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
