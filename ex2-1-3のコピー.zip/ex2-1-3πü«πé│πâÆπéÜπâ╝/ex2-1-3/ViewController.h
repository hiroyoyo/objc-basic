//
//  ViewController.h
//  ex2-1-3
//
//  Created by 佐野浩代 on 2017/01/03.
//  Copyright © 2017年 佐野浩代. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

